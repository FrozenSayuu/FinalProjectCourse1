<?php 
include '../Incl/header.php';
?>

      <div class="cont">
        <h1>About</h1>
        <div class="pic-about">
            <img class="tarot" src="../img/tarot-death.png" width="348" height="581" alt="tarot card death">
            <img class="tarot2" src="../img/tarot.png" width="348" height="581" alt="tarot card six of rings">
            
            <div class="p-about">
                <article>
                    <p>This website is created by me, Diana, your fellow witch friend.</p>
                    <p>A short story about me:</p>
                    <p>I have always been interested by uniqe rocks, I loved spending time in the forest and nature among the trees and flowers!</p>
                    <p>As long as I can remember I have been sensitive to energies but also negative people just because of the energy they sent out.</p>
                    <p>When I reached my teens I were introduced to crystals and I can tell you, I got hooked right away!</p>
                    <p>I have now over 20 crystals in my possesion that I use, I have both crystals for my home and room and also those I wear carry in my pocket!</p>
                    <p>It wasn't that long ago I started calling myself a witch, none the less practice it.</p>
                    <p>To know that I was one without realizing it myself was unexpected.</p>
                    <p>I only thought the reason why I was drawn to crystals were the reason I am energy sensitive and can feel their energy easily.</p>
                    <P>But I didn't understand the reason behind my fascination with the moon, nature and forest also zodiacs.</P>
                    <p>It wasn't until a friend brought up the subject about witches which brought my attention and I started reasearching.</p>
                    <p>I am deeply thankfull that my friend brought it up and opened this amazing and magical new world!</p>
                </article>
            </div>
            <div class="row">
                <div class="column">
                  <div class="card">
                    <img class="luna" src="../img/Luna.png" alt="Diana" width="2480" height="3508">
                    <div class="container">
                      <h2>Diana</h2>
                      <p class="title">Norse Pagan &amp; Eclectic</p>
                      <p>You can contact me on the Contact page</p>
                      <p>Blessed be~</p>
                    </div>
                  </div>
                </div>
            </div>
        </div>
      </div>
  <?php
  include '../Incl/footer.php';
  ?>