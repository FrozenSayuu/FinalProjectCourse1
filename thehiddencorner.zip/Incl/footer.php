        <footer>
            <nav class="footer-nav">
                <li><a href="blog.php">Blog</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </nav>
        </footer>
    </body>
</html>